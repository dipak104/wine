# Create Environment
# conda create -n wine python=3.7 -y

# Activate environment
# conda activate wine

# Install the requirements
# pip install -r requirements.txt